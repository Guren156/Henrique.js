const moment = require('moment');
//exibe a data e hora atual
const agora = moment().format('DD/MM/YYYY HH:mm:ss')
console.log("Data e Hora Atual:", agora);

const seteDiasDepois = moment().add(7,'days') .format('DD/MM/YYYY');
console.log("7 dias depois", seteDiasDepois)

const cincoDIasantes = moment().subtract(5, 'days').format('DD/MM/YYYY');
console.log("5 dias antes:", cincoDIasantes);

const mesesDepois = moment() .add(7,'month') .format('DD/MM/YYYY');
console.log("Meses depois:", mesesDepois);