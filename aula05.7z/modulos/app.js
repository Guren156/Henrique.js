// codigo pricipal
const funcaomulti = require('./multi')

console.log(funcaomulti(8,4))