const soma = function somar(a,b){
    return a+b
}

module.exports = soma //exportação do módulo