const sub = function sub(a,b){
    return a-b
}

module.exports = sub