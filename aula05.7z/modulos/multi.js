const multi = function multi(a,b){
    return a*b
}

module.exports = multi