const colors = require('colors')

console.log("Hello human".blue)