const calcularIdade = (AnoNascimento, anoAtual) => anoAtual - AnoNascimento
console.log(calcularIdade(2006, 2024))