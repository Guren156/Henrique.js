const readline = require('readline');

// criando uma interface para ler entrada e saída do terminal
const rl = readline.createInterface({
    input: process.stdin, //captura a entrada do terminal
    output: process.stdout // exibe saída do terminal
})

//Faz uma pergunta ao usúario
rl.question('Qual seu nome?', (nome) => {
    console.log(`Olá, ${nome}!`);
    rl.close(); //Fecha a interface após a resposta
})


